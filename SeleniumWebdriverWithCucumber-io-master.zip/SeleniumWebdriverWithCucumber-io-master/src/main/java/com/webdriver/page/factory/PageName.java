package com.webdriver.page.factory;

public enum PageName {
	HomePage,
	LoginPage,
	ProductDashboardPage,
	SearchPage,
	NewRunPage,
	NewCasePage,
	EnterBugPage
}
